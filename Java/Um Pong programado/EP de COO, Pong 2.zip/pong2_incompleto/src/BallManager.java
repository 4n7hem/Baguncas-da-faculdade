import java.awt.Color;
import java.lang.reflect.*;
import java.util.*;


public class BallManager {
	
	private HashMap<Long, IBall> todasAsBolas = new HashMap<Long, IBall>();
	private HashMap<Long, IBall> admVelocidade = new HashMap<Long, IBall>();
	private double velInicial;
	private long nanoTime = 0;
	private long tempContador;	
	
	private IBall theBall = null;
	
	private Class<?> ballClass = null;


	public BallManager(String className){

		try{
			ballClass = Class.forName(className);
		}
		catch(Exception e){

			System.out.println("Classe '" + className + "' não reconhecida... Usando 'Ball' como classe padrão.");
			ballClass = Ball.class;
		}
	}
	
	private double [] normalize(double x, double y){

		double length = Math.sqrt(x * x + y * y);

		return new double [] { x / length, y / length };
	}
	
	
	private IBall createBallInstance(double cx, double cy, double width, double height, Color color, double speed, double vx, double vy){

		IBall ball = null;
		double [] v = normalize(vx, vy);

		try{
			Constructor<?> constructor = ballClass.getConstructors()[0];
			ball = (IBall) constructor.newInstance(cx, cy, width, height, color, speed, v[0], v[1]);
		}
		catch(Exception e){

			System.out.println("Falha na instanciação da bola do tipo '" + ballClass.getName() + "' ... Instanciando bola do tipo 'Ball'");
			ball = new Ball(cx, cy, width, height, color, speed, v[0], v[1]);
		}

		return ball;
	} 	

	public void initMainBall(double cx, double cy, double width, double height, Color color, double speed, double vx, double vy){

		theBall = createBallInstance(cx, cy, width, height, color, speed, vx, vy);
		velInicial = theBall.getSpeed();
	}

	public void draw(){

		theBall.draw();
		Set teste = todasAsBolas.keySet();
		for(Object l : teste){
			IBall temp = (IBall) todasAsBolas.get(l);
			temp.draw();			
		}
	}	

	public void update(long delta){
	
		theBall.update(delta);
		nanoTime += delta;
		gerenciarBolas(todasAsBolas, nanoTime);
		gerenciarVelocidades(admVelocidade,nanoTime);
		Set teste = todasAsBolas.keySet();
		for(Object l : teste){
			IBall tempo = (IBall) todasAsBolas.get(l);
			tempo.update(delta);			
		}
	}	

	public int checkCollision(Wall wall){

		int hits = 0;

		if(theBall.checkCollision(wall)) hits++;
		
		Set teste = todasAsBolas.keySet();
		for(Object l : teste){
			IBall temp = (IBall) todasAsBolas.get(l);
			if(temp.checkCollision(wall)) hits++;
		}

		return hits;
	}
	
	public void checkCollision(Player player){

		theBall.checkCollision(player);
		Set teste = todasAsBolas.keySet();
		for(Object l : teste){
			IBall temp = (IBall) todasAsBolas.get(l);
			temp.checkCollision(player);
		}
	}

	public void checkCollision(Target target){

		boolean resposta = theBall.checkCollision(target);
		Long tStart = null;
		IBall copia = null;
		Set teste = todasAsBolas.keySet();
		
		for(Object l : teste){
			IBall temp = (IBall) todasAsBolas.get(l);
			boolean outraResp = temp.checkCollision(target);
			if(outraResp){
				if(target instanceof BoostTarget){
					if(!(temp.getSpeed() >= velInicial*2.5)){
						tempContador = nanoTime;
						temp.setSpeed(temp.getSpeed()*2.5);
						admVelocidade.put(tempContador, temp);
					}					
				}
				if(target instanceof DuplicatorTarget){
					tStart = nanoTime;
					copia = copiarBola(temp);					
				}
			}
		}
		if(copia != null) todasAsBolas.put(tStart, copia);
		
		
		if(resposta){
			if(target instanceof BoostTarget){				
				if(theBall.getSpeed() != (velInicial * 2.5)){
					tempContador = nanoTime;				
					theBall.setSpeed(theBall.getSpeed()*2.5);
					admVelocidade.put(tempContador, theBall);					
				}
			}
			else if(target instanceof DuplicatorTarget){
				tStart = nanoTime;				
				IBall bolaTemp = copiarBola(theBall);
				todasAsBolas.put(tStart, bolaTemp);				
			}
		}	
	}

	private void gerenciarBolas(HashMap m, long nanoTime){
		Set teste = m.keySet();
		if(!m.isEmpty()){			
			for(Iterator it = m.entrySet().iterator();
it.hasNext();){
				Map.Entry x =(Map.Entry) it.next();
				Long tempLong = (Long) x.getKey();				
				if(((nanoTime - tempLong.longValue())/1000.0)>=3.0){					
					it.remove();		
					
				}
			}			
		}
	}
	
	private void gerenciarVelocidades(HashMap m, long nanoTime){
		Set teste = m.keySet();
		if(!m.isEmpty()){			
			for(Iterator it = m.entrySet().iterator();
it.hasNext();){
				Map.Entry x =(Map.Entry) it.next();
				Long tempLong = (Long) x.getKey();				
				if(((nanoTime - tempLong.longValue())/1000.0)>=0.5){
					IBall temp = (IBall) x.getValue();
					temp.setSpeed(temp.getSpeed()/2.5);
					it.remove();		
					
				}
			}			
		}		
	}
	
	public IBall copiarBola(IBall bola){
		double cx = bola.getCx();
		double cy = bola.getCy();
		double height = bola.getHeight();
		double width = bola.getWidth();
		double speed = velInicial;
		double vx = bola.getVx();
		double vy = bola.getVy();		
		return createBallInstance(cx,cy,width,height,Color.RED,speed,vx*Math.random()*0.15+(0.01),vy*Math.random()*0.15);
	
	}
}
