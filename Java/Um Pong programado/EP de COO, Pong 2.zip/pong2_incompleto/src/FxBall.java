import java.awt.*;
import java.util.*;


public class FxBall extends Ball implements IBall{
	
	private Queue<Fx> q = new LinkedList<>();	
	
	
	public FxBall(double cx, double cy, double width, double height, Color color, double speed, double vx, double vy){

		super(cx, cy, width, height, color, speed, vx, vy);
		criarParticulas();
	}

	public void updateParticulas(){
		
		if(q.peek().getContador() >= 45){
			q.poll();
		}
		for(Object item : q){
			Fx temp = (Fx) item;
			temp.somarContador();			
			temp.reduzirParticula();
		}		
	}
	
	public void criarParticulas(){
		Fx base = new Fx(this.getCx(), this.getCy(), this.getWidth(), this.getHeight(), this.getColor());		
		base.reduzirParticula();
		q.add(base);		
	}

	@Override	
	public void draw(){		
		GameLib.setColor(getColor());
		GameLib.fillRect(this.getCx(),this.getCy(),this.getWidth(),this.getHeight());
		this.criarParticulas();
		this.updateParticulas();
	}
}