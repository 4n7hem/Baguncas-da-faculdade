import java.awt.*;

public class Fx{
	
	private double cx; 
	private double cy;
	private double height;
	private double width;
	private Color color;
	private int contador = 0;
	
	
	
	public Fx(double cx, double cy, double width, double height, Color color){
		this.cx = cx;
		this.cy = cy;
		this.width = width;
		this.height = height;
		this.color = color;
			
	}
	
	public void draw(){
		GameLib.setColor(this.color);
		GameLib.fillRect(this.cx,this.cy,this.width,this.height);		
	}
	
	public void update(FxBall bola){
		this.cx = bola.getCx();
		this.cy = bola.getCy();
	}
	
	public void update(Fx part){
		this.cx = part.getCx();
		this.cy = part.getCy();
	}
	
	public Fx copiarParticula(Fx f){
		Fx resposta = new Fx(f.getCx(), f.getCy(), f.getWidth(), f.getHeight(), f.getColor().darker());
		return resposta;
	}

	public void reduzirParticula(){
		if(contador % 8 == 0){
			this.setColor(this.getColor().darker());			
		}
		else{ this.setColor(this.getColor()); }		
		this.width = this.width *0.97;
		this.height = this.height *0.97;
		this.draw();			
	}
	
	public double getWidth(){
		return this.width;	
	}
	
	public double getHeight(){
		return this.height;
	}
	
	public double getCx(){
		return this.cx;
	}
	
	public double getCy(){
		return this.cy;
	}
	
	public void setCx(double novo){
		this.cx = novo;
	}
	
	public void setCy(double novo){
		this.cy = novo;
	}
	

	public void setColor(Color cor){
		this.color = cor;
	}
	
	public Color getColor(){
		return this.color;
	}
	
	public void somarContador(){
		contador++;
	}
	
	public int getContador(){
		return contador;
	}
	
}